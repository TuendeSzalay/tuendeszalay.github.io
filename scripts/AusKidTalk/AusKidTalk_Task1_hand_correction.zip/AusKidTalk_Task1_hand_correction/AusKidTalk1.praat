# OVERVIEW
# This script was written for the AusKidTalk project (LE190100187, website: https://www2.ee.unsw.edu.au/~auskidtalk/index.html) by Tuende Szalay (tuende.szalay@sydney.edu.au). 

# The aim of this script is to assist annotators in hand-correcting automatically generated time-alignment and orthographic transcriptions. 
# To achieve this, the script automatically identifies those intervals that are the most likely to contain target words.

# Annotator tasks:
## Decide if the interval contains a target word produced by the child
## Decide if the transcription is correct, and edit the transcription if it is incorrect.
## Decide if time-alingment is correct, and edit the boundaries, if the time alignment is incorrect.

# Input:
## Input data are to be placed in the sound folder, with each participant's data saved in its own subfolder as Sound/ChildID (e.g., sound/98, sound/144)
## One participant's data consists of three files: 
### Task(1) wav file, named as ChildID_task1.wav (e.g., 98_task1.wav)
### Task(1) textgrid with two tiers (Tier 1: Prompt, mapping the audio to prompt presentation; Tier 2: automatic orthographic transcription for the participant's speech), named as ChildID_task1.TextGrid (e.g., 98_task1.TextGrid)

# Output:
# Output data are saved by the script in the corrected folder.
# There are two files for each corrected participant:
## Task(1) textgrid with the hand-corrected orthographic transcription named as ChildID_task1_corrected.TextGrid (e.g., 98_task1_corrected.TextGrid)
## Task(1) csv containing the hand-corrected targets and their start- and end-times in a csv file named as ChildID_task1_corrected.csv (e.g., 98_task1_corrected.TextGrid )

# Metadata:
# The metadata folder contains a set of txt and csv files required for the script.
# Target lists
## prompts.txt and eggs.txt list all the prompts used in AusKidTalk Task(1)
# Name of annotators
## The name of annotators and their affiliations are listed in a csv to track who corrected which file for quality control
## Annotator names are added to the csv manually.
# Phonetic transcriptions
## Phonetic transcriptions are provided for every target in the folder phonemediff.
## Transcriptions follow a non-traditional system used solely for the AusKidTalk project to avoid the need to code IPA symbols
# Tracker file for annotators' decision
## The file extracted_targets.csv logs annotators decision on the interval, the orhographic transcription, and the boundary.

# Training:
# The training folder contains the following folders:
## metadata (as above)
## corrected (as above)
## sound (contains a single shortened wav file that exemplifies typical challenges of the AusKidTalk data)

# FURTHER DETAILS
# Szalay, T., Ratko, L., Shahin, M., Sirojan, T., Ballard, K., Cox, F., & Ahmed, B. (2022). A semi-automatic workflow for orthographic transcription of a novel speech corpus: A case study of AusKidTalk. In Rosey Billington (Ed.) Proceedings of the 18th Australasian International Conference on Speech Science and Technology, 126-130.
# For more details on AusTalk, see
# Ahmed, B., Ballard, K. J., Burnham, D., Sirojan, T., Mehmood, H., Estival, D., ... & Ambikairajah, E. (2021). AusKidTalk: an auditory-visual corpus of 3-to 12-year-old Australian children’s speech. In Proc. Interspeech 2021 (pp. 3680-3684).

# REFERENCE
# For using this script, please cite
# Szalay, T., Ratko, L., Shahin, M., Sirojan, T., Ballard, K., Cox, F., & Ahmed, B. (2022). A semi-automatic workflow for orthographic transcription of a novel speech corpus: A case study of AusKidTalk. In Rosey Billington (Ed.) Proceedings of the 18th Australasian International Conference on Speech Science and Technology, 126-130.

# ACKNOWLEDGMENT
# This work was supported by the Australian Research Council LE190100187 Grant.


#Define variables
promptTier = 1
wordTier = 2
huTier = 3
flagTier = 4
prev = 0 
maxError = 11

noise = 0 


call whoDis

stringOfTargets = Read Strings from raw text file: metadir$ + "prompt.txt"
listOfTargets = To WordList

stringOfEggs = Read Strings from raw text file: metadir$ + "eggs.txt"
nEgg = Get number of strings
listOfEggs = To WordList

Create Strings as folder list: "participantList", sourcedir$
nFile = Get number of strings

call counterZero

select analysedTable
counterValue = Get value: counterSoundZero , "SoundCounter"
assignedAnnotator$ = Get value: counterSoundZero , "Annotator"
soundName$ = Get value: counterSoundZero , "SoundFile"
itemName$ = left$(soundName$, length(soundName$)-4)
saveGridName$ = left$(soundName$, length(soundName$)-4) + "_corrected"	

#check if files exist	
soundExists = fileReadable(sourcedir$ + partID$ + "/" + soundName$)
textGridName$ = itemName$ + ".TextGrid"
textGridExists = fileReadable(sourcedir$ + partID$ + "/" + textGridName$)

if soundExists == 0 or textGridExists == 0
	notFound$ = "Error: No webtool data are found for speaker " + partID$
	call fileNotFound
endif

sound = Read from file: sourcedir$ + partID$ + "/" + soundName$ 

if reload == 0
	pauseScript: "You will start working with "  + soundName$ + ", a new file"		
	select listOfTargets
	stringOfFound = Create Strings from tokens: "stringOfFound", "", " ,"

	#load  grid
	textGrid = Read from file: sourcedir$ + partID$ + "/" + textGridName$
	nTier = Get number of tiers
	
	if nTier <> 2
		pauseScript:"There is an unexpected number of speaker tiers. Notify your supervisor!"
		goto EXIT
	endif

	#vacuous for prompt tier, might do something on the word-tier. best to leave in for safety
	for iTier to nTier
		Replace interval texts: iTier, 1, 0, " ", "_", "literals"
	endfor	
	
	Duplicate tier: wordTier, nTier + 1, "hu-wrd"
	Insert point tier: nTier + 2, "flag"
	Save as text file: outdir$ + saveGridName$ + ".TextGrid"
	nemoTier$ = Get tier name: wordTier

	promptGrid = Extract one tier: promptTier
	select textGrid	
	wordGrid = Extract one tier: wordTier

	select analysedTable
	Set string value: counterSoundZero , "SpeakerTier", nemoTier$
	Save as comma-separated file: metadir$ + "analysed_files.csv"	

	beginPause: "Start working"
	comment: "File: " + fileName$ 
	comment: "Iteration: " + string$ (itValue+1)
	comment: "The ASR matched the child's speech with the prompt"
	endPause: "Continue", 1

	itValue = 1

elsif reload == 1
	#check if saved data is still there and load it
	stringOfFoundExists  = fileReadable (metadir$ + itemName$ + "stringOfFound.txt")
	textGridExists = fileReadable (outdir$ + saveGridName$ + ".TextGrid")

	if stringOfFoundExists == 0 or textGridExists == 0
		notFound$ = "Error: Your previous work for speaker" + partID$ + " is not found"
		call fileNotFound
	endif

	stringOfFound = Read Strings from raw text file: metadir$ + itemName$ + "stringOfFound.txt"	
	textGrid = Read from file: outdir$ + saveGridName$ + ".TextGrid"	
	promptGrid = Extract one tier: promptTier

	select textGrid
	wordGrid = Extract one tier: wordTier

endif

#create table with all the words that appear in the textgrid
select wordGrid
tableAll = Down to Table: "no", 2, "yes", "no"
tableWord = Extract rows where column (text): "text", "is not equal to", "sil"
nWord = Get number of rows

while itValue == 1
	for iWord from intValue+1 to nWord
		select tableWord
		kaldi$ = Get value: iWord, "text"
		startWindow = Get value: iWord, "tmin"
		endWindow = Get value: iWord, "tmax"	
		midWindow = startWindow + ((endWindow - startWindow)/2)
		
		select textGrid
		intPromptNumber = Get interval at time: promptTier, midWindow
		prompt$ = Get label of interval: promptTier, intPromptNumber	
		
		if kaldi$ == prompt$
			targetMatch = 1
		elif prompt$ == "count_eggs_in_grass" & (kaldi$ == "one" or kaldi$ == "two" or kaldi$ == "three" or kaldi$ == "four" or kaldi$ == "five" or kaldi$ == "six" or kaldi$ == "seven" or kaldi$ == "eight" or kaldi$ == "nine" or kaldi$ == "ten")
			targetMatch = 1
		elif prompt$ == "one_cup" & ( kaldi$ == "one" or kaldi$ == "cup")
			targetMatch = 1 
		elif prompt$ == "two_cups" & ( kaldi$ == "two" or kaldi$ == "cups")
			targetMatch = 1
		elif prompt$ == "three_cups" & ( kaldi$ == "three" or kaldi$ == "cups")
			targetMatch = 1
		elif prompt$ == "four_cups" & ( kaldi$ == "four" or kaldi$ == "cups")
			targetMatch = 1
		elif prompt$ == "one_egg" & ( kaldi$ == "one" or kaldi$ == "egg")
			targetMatch = 1 
		elif prompt$ == "two_eggs" & ( kaldi$ == "two" or kaldi$ == "eggs")
			targetMatch = 1
		elif prompt$ == "three_eggs" & ( kaldi$ == "three" or kaldi$ == "eggs")
			targetMatch = 1
		elif prompt$ == "four_eggs" & ( kaldi$ == "four" or kaldi$ == "eggs")
			targetMatch = 1
		elif prompt$ == "one_o_clock" & ( kaldi$ == "one" or kaldi$ == "clock")
			targetMatch = 1 
		elif prompt$ == "two_o_clock" & ( kaldi$ == "two" or kaldi$ == "clock")
			targetMatch = 1
		elif prompt$ == "three_o_clock" & ( kaldi$ == "three" or kaldi$ == "clock")
			targetMatch = 1
		elif prompt$ == "four_o_clock" & ( kaldi$ == "four" or kaldi$ == "clock")
			targetMatch = 1
		elif prompt$ == "duck" & kaldi$ == "ducky"
			targetMatch = 1
		elif prompt$ == "fish" & kaldi$ == "fishy"
			targetMatch = 1
		elif prompt$ == "frog" & kaldi$ == "froggy"
			targetMatch = 1
		elif prompt$ == "hippopotamus" & kaldi$ == "hippo"
			targetMatch = 1
		elif prompt$ == "owl" & kaldi$ == "owlet"
			targetMatch = 1
		elif prompt$ == "pig" & kaldi$ == "piggy"
			targetMatch = 1
		elif prompt$ == "rhinoceros" & kaldi$ == "rhino"
			targetMatch = 1
		elif prompt$ == "spiderweb" & kaldi$ == "spider"
			targetMatch = 1
		elif prompt$ == "bellybutton" & kaldi$ = "belly"
			targetMatch = 1	
		else
			targetMatch = 0
		endif

		if targetMatch == 1
			iteration$ = "TargetWord"
			call evaluate
			while errorAuTiers == 1 or errorHuTier == 1 or errorTranscription == 1
				call foolproofish
			endwhile
			call noise
			call adult
			call save
		endif
	#for iWord to nWord
	endfor	

	intValue = 0
	itValue = 2

	select analysedTable
	Set numeric value: counterSoundZero, "IterationCounter", 'itValue'
	Set numeric value: counterSoundZero, "IntervalCounter", 'intValue'
	Set string value: counterSoundZero, "LastPrompt", ""
	Save as comma-separated file: metadir$ + "analysed_files.csv"	
#while itValue == 1
endwhile

while itValue == 2
	#Note: the while-loop only runs once, because after the for-iWord loop ends, itValue is changed. 
	#That is, call notFound only runs once, before we get into the for-iWord.
	#That is, if you find once instance of "key", "key" won't be immediately removed from the notFoundList.
	#That is, the RA can check all the following intervals for the prompt "key"
	call notFound

	if reload == 0 or ogItValue != 2
		beginPause: "Continue working"
		comment: "File: " + fileName$ 
		comment: "Iteration: " + string$ (itValue)
		comment: "The ASR identified the child's voice, but not the target"
		endPause: "Continue", 1
	endif

	for iWord from intValue+1 to nWord
		select tableWord
		kaldi$ = Get value: iWord, "text"
		startWindow = Get value: iWord, "tmin"
		endWindow = Get value: iWord, "tmax"	
		midWindow = startWindow + ((endWindow - startWindow)/2)
		
		select textGrid
		intPromptNumber = Get interval at time: promptTier, midWindow
		prompt$ = Get label of interval: promptTier, intPromptNumber
		intHuNumber = Get interval at time: huTier, midWindow
		huWord$ = Get label of interval: huTier, intHuNumber
		huSil = huWord$ == "sil"


		select listOfNotFound
		promptOnNotFound = Has word: prompt$


		select listOfFound
		wordOnFound = Has word: kaldi$
	
		if prompt$ == lastPrompt$
			promptMatch = 1
		elif lastPrompt$ == ""
			promptMatch = 1
		else
			promptMatch = 0
		endif 
	
		if reload == 1 and ogItValue == itValue and promptMatch == 1 and huSil != 1
			iteration$ = "AllWords"
			call evaluate
			while errorAuTiers == 1 or errorHuTier == 1 or errorTranscription == 1
				call foolproofish
			endwhile
			call noise
			call adult
			call save
		#finds all 3 reps of "rhino" in the absence of one rhinoceros:
		#elif promptOnNotFound == 1 
		#finds 1st rep of "rhino" in the absence of one rhinoceros:
		elif (promptOnNotFound == 1 & huSil != 1) or prev == 1
			if prompt$ == "count_eggs_in_grass" 
				if wordOnFound == 0
					iteration$ = "AllWords"
					call evaluate
					while errorAuTiers == 1 or errorHuTier == 1 or errorTranscription == 1	
						call foolproofish
					endwhile
					call noise
					call adult
					call save
				endif

			else
				iteration$ = "AllWords"
				call evaluate
				while errorAuTiers == 1 or errorHuTier == 1 or errorTranscription == 1	
					call foolproofish
				endwhile
				call noise
				call adult
				call save
			endif
		endif	
	#for iWord to nWord
	endfor

	#Interim cleanup of temporary objects
	select Strings stringOfNotFound
	plus listOfNotFound
	plus listOfFound 
	Remove

	intValue = 0
	itValue = 3
	select analysedTable
	Set numeric value: counterSoundZero , "IterationCounter", 'itValue'
	Set numeric value: counterSoundZero , "IntervalCounter", 'intValue'
	Set string value: counterSoundZero , "LastPrompt", ""
	Save as comma-separated file: metadir$ + "analysed_files.csv"	

#while itValue == 2
endwhile

while itValue == 3
	call notFound

	select promptGrid
	tableAllPrompt = Down to Table: "no", 2, "yes", "no"
	tablePrompt = Extract rows where column (text): "text", "is not equal to", "sil"
	nWord = Get number of rows

	if reload == 0 or ogItValue != 3
		beginPause: "Continue working"
		comment: "File: " + fileName$ 
		comment: "Iteration: " + string$ (itValue)
		comment: "The ASR couldn't identify the child's voice"
		endPause: "Continue", 1
	endif
	for iWord from intValue+1 to nWord
		select tablePrompt
		prompt$ = Get value: iWord, "text"
		startWindow = Get value: iWord, "tmin"
		endWindow = Get value: iWord, "tmax"
		midWindow = startWindow + ((endWindow - startWindow)/2)
		
		select textGrid
		intPromptNumber = Get interval at time: promptTier, midWindow

		select listOfNotFound
		promptOnNotFound = Has word: prompt$


	 
		if reload == 1 and ogItValue == itValue and prompt$ == lastPrompt$
			iteration$ = "Prompt"
			call evaluate
			while errorAuTiers == 1 or errorHuTier == 1 or errorTranscription == 1
				call foolproofish
			endwhile
			call noise
			call adult
			call save
		elif promptOnNotFound == 1
			iteration$ = "Prompt"
			call evaluate
			while errorAuTiers == 1 or errorHuTier == 1 or errorTranscription == 1
				call foolproofish
			endwhile
			call noise
			call adult
			call save
		 endif
	#for iWord to iWord
	endfor


	itValue = 0
	intValue = 0 
#while itValue == 3
endwhile

#Clear up hu-tier and extract target location as CSV
select textGrid
nHuInt = Get number of intervals: huTier
for iHuInt to nHuInt
	select textGrid
	huIntStart = Get start time of interval: huTier, iHuInt
	huIntEnd = Get end time of interval: huTier, iHuInt
	huIntLabel$ = Get label of interval: huTier, iHuInt

	promptInt = Get interval at time: promptTier, huIntStart + ((huIntEnd - huIntStart)/2)
	promptLabelUpper$ = Get label of interval: promptTier, promptInt

	if huIntLabel$ == promptLabelUpper$
	elif promptLabelUpper$ == "count_eggs_in_grass" & (huIntLabel$ == "one" or huIntLabel$ == "two" or huIntLabel$ == "three" or huIntLabel$ == "four" or huIntLabel$ == "five" or huIntLabel$ == "six" or huIntLabel$ == "seven" or huIntLabel$ == "eight" or huIntLabel$ == "nine" or huIntLabel$ == "ten")
	else
		Set interval text: huTier, iHuInt, "sil"
	endif	
endfor

select textGrid
editGrid = Extract one tier: huTier
select textGrid
flagGrid = Extract one tier: flagTier
select promptGrid
plus wordGrid
plus editGrid
plus flagGrid
saveGrid = Merge
Save as text file: outdir$ + saveGridName$ + ".TextGrid"

select editGrid
allHuTable = Down to Table: "no", 6, "yes", "no"
targHuTable = Extract rows where column (text): "text", "is not equal to", "sil"
Append column: "Noise"
Append column: "Difference1"
Append column: "Difference2"
Append column: "Difference3"
Append column: "Difference4"
Append column: "Difference5"
Append column: "Difference6"
Append column: "Difference7"
Append column: "Difference8"
Append column: "Difference9"
Append column: "Difference10"
Append column: "Difference11"
Append column: "Added"
Formula: "Difference1", """NA"""
Formula: "Difference2", """NA"""
Formula: "Difference3", """NA"""
Formula: "Difference4", """NA"""
Formula: "Difference5", """NA"""
Formula: "Difference6", """NA"""
Formula: "Difference7", """NA"""
Formula: "Difference8", """NA"""
Formula: "Difference9", """NA"""
Formula: "Difference10", """NA"""
Formula: "Difference11", """NA"""
Formula: "Added", """NA"""
Formula: "Noise", """FALSE"""
nHuInt = Get number of rows
for iHuInt to nHuInt
	select targHuTable
	cTMin = Get value: iHuInt, "tmin"
	cTMin$ = fixed$ (cTMin, 2)
	cTMin = number (cTMin$)
	cTMax = Get value: iHuInt, "tmax"
	cTMax$ = fixed$ (cTMax, 2)
	cTMax = number (cTMax$)
	cTMid = cTMin + ((cTMax - cTMin)/2) 

	select textGrid
	lowIndex = Get low index from time: flagTier, cTMid
	maxIndex = Get number of points: flagTier
	
	if lowIndex != 0
		select textGrid
		lowTime = Get time of point: flagTier, lowIndex
		if lowTime > cTMin 
			select targHuTable
			Set string value: iHuInt, "Noise", "TRUE"
		endif	
	endif
	
	for iError to maxError
		expectedTime =  cTMid + 0.005 * iError
		expectedTime = 'expectedTime:3'

		select textGrid
		highIndex = Get nearest index from time: flagTier, expectedTime
		if highIndex != 0 and highIndex <= maxIndex
			select textGrid
			highTime = Get time of point: flagTier, highIndex 
			highTime = 'highTime:3'

			if highTime == expectedTime and highTime < cTMax
				select textGrid
				phon$ = Get label of point: flagTier, highIndex 
				select targHuTable
				if iError <= maxError	
					Set string value: iHuInt, "Difference" + string$(iError), phon$
				elif iError == maxError + 1
					Set string value: iHuInt, "Added", phon$
				endif
			endif
		endif
	#for maxError errors
	endfor
	
	
#for iHuInt to nHuInt
endfor
select targHuTable
Save as comma-separated file: outdir$ + saveGridName$ + ".csv"

select editGrid	
plus saveGrid
Remove

#Update countertable for files
select analysedTable

if annotatorName$ == "TRAINING"
	Set numeric value: counterSoundZero , "SoundCounter", 0
	Set string value: counterSoundZero , "SpeakerTier", ""
	Set numeric value: counterSoundZero , "IterationCounter", 0	
	Set numeric value: counterSoundZero , "IntervalCounter", 0	
	Set string value: counterSoundZero , "LastPrompt", ""
	Set string value: counterSoundZero , "Annotator", "TRAINING"	
	Save as comma-separated file: metadir$ + "analysed_files.csv"
	
else
	Set numeric value: counterSoundZero , "SoundCounter", counterValue + 1
	Save as comma-separated file: metadir$ + "analysed_files.csv"
endif

select sound
plus promptGrid
plus wordGrid
plus textGrid
plus tableAll
plus tableWord
plus tableAllPrompt
plus tablePrompt
plus listOfFound
plus stringOfFound
plus Strings stringOfNotFound
plus listOfNotFound
Remove

reload = 0

pauseScript: "You've hand-corrected all data for Speaker " + partID$ + ". Please upload the corrected textgrid and csv to the webtool!"
label EXIT

################################################### Identify prompts that haven't yet been found #########################################
procedure notFound
	Create Strings from tokens: "stringOfNotFound", "", " ,"
	foundEggValue = 0

	#stringOfFound is created when RA selects Accept or Add for interval
	select stringOfFound
	listOfFound = To WordList
	
	for iEgg to nEgg
		select stringOfEggs
		number$ = Get string: iEgg
		
		select listOfFound
		newValue = Has word: number$
		foundEggValue = foundEggValue + newValue
	endfor
	
					
	select stringOfTargets
	nTarget = Get number of strings
	for iTarget to nTarget
		select stringOfTargets
		prompt$ = Get string: iTarget
		#promptLower$ = replace_regex$ (prompt$, "[A-Z]", "\L&", 0)
			
		select listOfFound
		foundValue = Has word: prompt$
		
		if prompt$ == "count_eggs_in_grass" & foundEggValue < nEgg
			select Strings stringOfNotFound
			Insert string: 0, prompt$			
		elif prompt$ != "count_eggs_in_grass" and foundValue = 0
			select Strings stringOfNotFound
			Insert string: 0, prompt$
		endif
	endfor
		
	select Strings stringOfNotFound
	listOfNotFound = To WordList
	
endproc	

###################################################        EVALUATE interval, label, and boundary     ###################################
procedure evaluate

#save old data
select textGrid
if itValue == 1 or itValue == 2
	startIBM = startWindow
	endIBM = endWindow
	intIBMNumber = Get interval at time: wordTier, midWindow	

	startPrompt = Get start time of interval: promptTier, intPromptNumber
	startPrompt$ = fixed$ (startPrompt, 2)
	startPrompt = number (startPrompt$)
	endPrompt = Get end time of interval: promptTier, intPromptNumber
	endPrompt$ = fixed$ (endPrompt, 2)
	endPrompt = number (endPrompt$)

	windowLabel$ = kaldi$

elsif itValue == 3
	startPrompt = startWindow
	endPrompt = endWindow

	midWindow = startWindow + ((endWindow - startWindow)/2)
	intIBMNumber = Get interval at time: wordTier, midWindow
	startIBM = Get start time of interval: wordTier, intIBMNumber
	startIBM$ = fixed$ (startIBM, 2)
	startIBM = number (startIBM$)
	endIBM = Get end time of interval: wordTier, intIBMNumber
	endIBM$ = fixed$ (endIBM, 2)
	endIBM = number (endIBM$)
	kaldi$ = Get label of interval: wordTier, intIBMNumber

	windowLabel$ = prompt$
endif

#begin edits
label CHANGE_INT_EVAL

#No "accept" option for iteration 3
if itValue == 3
	beginPause: "Evaluate the interval for " + windowLabel$ + "!"
		select sound
		plus textGrid
		View & Edit
		select textGrid
		textGridName$ = selected$ ("TextGrid", 1 )	
		editor TextGrid 'textGridName$'
			Zoom... startWindow-0.1 endWindow+0.2
			Select... startWindow endWindow
			Play... startWindow endWindow
		endeditor
	intClicked = endPause: "Add","NotTarget", "NotKid", "Prev.word", 1
	if intClicked == 1
		 intClicked = 4
	elif intClicked == 4
		intClicked = 5
	endif	

else
	beginPause: "Evaluate the interval for " + windowLabel$ + "!"
		select sound
		plus textGrid
		View & Edit
		select textGrid
		textGridName$ = selected$ ("TextGrid", 1 )	
		editor TextGrid 'textGridName$'
			Zoom... startWindow-0.1 endWindow+0.2
			Select... startWindow endWindow
			Play... startWindow endWindow
		endeditor
	intClicked = endPause: "Accept", "NotTarget", "NotKid", "Add", "Prev.word", 1
endif
	
if intClicked = 1
	label CHANGE_LAB_BOUNDARY
	intEvaluation$ = "Accepted"
	prev = 0
	
	#evaluate label and boundary
	if iteration$ = "TargetWord"
		word = 1
	elif iteration$ = "AllWords"
		word = 2
	endif
	boundary = 1

	beginPause: "Evaluate transcription and boundary for " + windowLabel$ + "!"
		choice: "Word", word
			option: "WordCorrect"
			option: "WordEdit"
		choice: "Boundary", boundary
			option: "BoundaryCorrect"
			option: "BoundaryEdit"	
	clicked = endPause: "Next/Edit", 1
	
	if word == 2 or boundary == 2
		#edit
		label EDIT
		beginPause: "Edit label and/or boundary and select the Target interval when done"
		clicked = endPause: "Cont.", 1
		editor TextGrid 'textGridName$'
			startHu = Get start of selection
			startHu$ = fixed$ (startHu, 2)
			startHu = number (startHu$)	
			endHu = Get end of selection
			endHu$ = fixed$ (endHu, 2)
			endHu = number (endHu$) 
			target$ = Get label of interval
		endeditor	
		
	elsif word == 1 and boundary == 1
		select textGrid
		intHuNumber = Get interval at time: huTier, midWindow
		startHu = Get start time of interval: huTier, intHuNumber
		startHu$ = fixed$ (startHu, 2)
		startHu = number (startHu$)	
		endHu = Get end time of interval: huTier, intHuNumber
		endHu$ = fixed$ (endHu, 2)
		endHu = number (endHu$) 
		target$ = Get label of interval: huTier, intHuNumber
		
	#if Edit == TRUE/FALSE
	endif
	
	if word == 1
		labelEvaluation$ = "Accepted"
	elsif word == 2
		labelEvaluation$ = "Edited"
	endif

	if boundary == 1
		boundaryEvaluation$ = "Accepted"
	elsif boundary == 2
		boundaryEvaluation$ = "Edited"
	endif
	
elsif intClicked = 2
	prev = 0
	intEvaluation$ = "Deleted-Kid"
	labelEvaluation$ = "Deleted"
	boundaryEvaluation$ = "Deleted"

	target$ = "NA"
	startHu = -999
	endHu = -999
	
	select textGrid
	delInt = Get interval at time: huTier, startWindow + ((endWindow-startWindow)/2)	
	Set interval text: huTier, delInt, "sil"

elsif intClicked = 3
	prev = 0
	intEvaluation$ = "Deleted-NotKid"
	labelEvaluation$ = "Deleted"
	boundaryEvaluation$ = "Deleted"
	
	target$ = "NA"
	startHu = -999
	endHu = -999
	
	select textGrid
	delInt = Get interval at time: huTier, startWindow + ((endWindow-startWindow)/2)		
	Set interval text: huTier, delInt, "sil"

elsif intClicked = 4
	prev = 0
	beginPause: "Add interval and label and select Target interval when done"	
	clicked = endPause: "Cont.", "Add another", 1
	editor TextGrid 'textGridName$'
		startHu = Get start of selection
		endHu = Get end of selection
		target$ = Get label of interval
	endeditor	
	
	intEvaluation$ = "Added"
	labelEvaluation$ = "Added"
	boundaryEvaluation$ = "Added"	
	startWindowOld = startWindow
	endWindowOld = endWindow
	startWindow = -999
	endWindow = - 999

	if clicked = 2
		call noise
		call adult
		call save
		startWindow = startWindowOld
		endWindow = endWindowOld
		goto CHANGE_INT_EVAL
	endif

elsif intClicked = 5
	select analysedTable
	itValue = Get value: counterSoundZero , "IterationCounter"
	prevInt = Get value: counterSoundZero , "IntervalCounter"
	prevInt = prevInt  - 1

	if prevInt < 0
		prev = 0
		editor TextGrid 'textGridName$'
			Close
		endeditor
		pauseScript: "You can't go back, because you're on the first word in this iteration!"
		goto CHANGE_INT_EVAL
	else
		iWord = prevInt
		intEvaluation$ = ""
		prev = 1
	endif	
#if intClicked == X
endif

#trigger evaluation procedure
if intClicked == 1
	errorAuTiers = 1
	errorHuTier = 1
	errorTranscription = 1
elif intClicked == 4
	errorAuTiers = 1
	errorHuTier = 0
	errorTranscription =1
else 
	errorAuTiers = 0
	errorHuTier = 0
	errorTranscription = 0		
endif	

endproc

###################################################            CHECK THE RA'S WORK                             ###################################
procedure foolproofish

#check if prompt and automatic tier have been edited 
select textGrid
newKaldi$ = Get label of interval: wordTier, intIBMNumber
newStartIBM = Get start time of interval: wordTier, intIBMNumber
newStartIBM$ = fixed$ (newStartIBM, 2)
newStartIBM = number (newStartIBM$)
newEndIBM = Get end time of interval: wordTier, intIBMNumber
newEndIBM$ = fixed$ (newEndIBM, 2)
newEndIBM = number (newEndIBM$)

newPrompt$ = Get label of interval: promptTier, intPromptNumber
newStartPrompt = Get start time of interval: promptTier, intPromptNumber
newStartPrompt$ = fixed$ (newStartPrompt, 2)
newStartPrompt = number (newStartPrompt$)
newEndPrompt = Get end time of interval: promptTier, intPromptNumber
newEndPrompt$ = fixed$ (newEndPrompt, 2)
newEndPrompt = number (newEndPrompt$)

kaldiMatch = kaldi$ == newKaldi$
startIBMMatch = startIBM == newStartIBM 
endIBMMatch = endIBM == newEndIBM 

if prompt$ == newPrompt$
	promptMatch = 1
else
	promptMatch = 0
endif
startPromptMatch = startPrompt == newStartPrompt 
endPromptMatch = endPrompt == newEndPrompt 


if (kaldiMatch + startIBMMatch + endIBMMatch) < 3 and (promptMatch + startPromptMatch + endPromptMatch ) < 3
	pauseScript: "You've edited the prompt and the automatic tiers. You must NOT do so, and these edits are NOT saved!"
elsif (kaldiMatch + startIBMMatch + endIBMMatch) < 3
	pauseScript: "You've edited the automatic tier. You must NOT do so, and this edit is NOT be saved!"
elsif (promptMatch + startPromptMatch + endPromptMatch ) < 3
	pauseScript: "You've edited the prompt tier. You must NOT do so, and this edit is NOT be saved!"
endif
#we only warn about not saving unnecessary edits once per interval
errorAuTiers = 0

if errorHuTier == 1
	#we check for missing, unnecessary or otherwise inconsistent edits
	if labelEvaluation$ == "Edited" and target$ == kaldi$
		labelNotEdited = 1
		labelNotEdited$ = "You've selected WordEdit but did not change the label on the human tier!"
	elsif labelEvaluation$ == "Accepted" and target$ != kaldi$
		labelNotEdited = 1
		labelNotEdited$ = "You've selected WordCorrect, but changed the label on the human tier!"
	else
		labelNotEdited = 0
	endif

	if boundaryEvaluation$ == "Edited" and startHu == startIBM and endHu == endIBM
		boundaryNotEdited = 1
		boundaryNotEdited$ = "You selected BoundaryEdit but did not change any of the boundaries on the human tier!"
	elsif boundaryEvaluation$ == "Accepted" and (startHu != startIBM or endHu != endIBM)
		boundaryNotEdited = 1
		boundaryNotEdited$ = "You selected BoundaryCorrect but changed one/two of the boundaries on the human tier!"
	else
		boundaryNotEdited = 0
	endif

	if  labelNotEdited == 1 and boundaryNotEdited == 1
		beginPause: "Incorrect edits!"
		comment: labelNotEdited$
		comment: boundaryNotEdited$
		comment: "Or you highlighted the wrong interval."
		clicked = endPause: "Change evaluation!", "Edit the interval!", 1
	elsif labelNotEdited == 1
		beginPause: "Incorrect edits!"
		comment: labelNotEdited$
		comment: "Or you highlighted the wrong interval."
		clicked = endPause: "Change evaluation!", "Edit the interval!", 1
	elsif boundaryNotEdited == 1
		beginPause: "Incorrect edits!"
		comment: boundaryNotEdited$
		comment: "Or you highlighted the wrong interval."
		clicked = endPause: "Change evaluation!", "Edit the interval!", 1

	else
		clicked = 0
		errorHuTier = 0
	endif 

	if clicked == 1
		goto CHANGE_LAB_BOUNDARY
	elsif clicked == 2
		goto EDIT
	endif

#if errorHuTier == 1
endif

#check if target matches the prompt
if target$ == prompt$
	transcriptionMatch = 1
#elif target$ == promptLower$
#	transcriptionMatch = 1
elif prompt$ == "count_eggs_in_grass" 
	select listOfEggs
	transcriptionMatch = Has word: target$
else
	transcriptionMatch = 0
endif	

if transcriptionMatch == 0
	if intEvaluation$ == "Accepted"
		beginPause: "Your transcription doesn't match the prompt!"
		comment: "You've clicked Accept for the interval, but the transcription doesn't match the prompt."
		comment: "You should only accept an interval if the child's production matches the prompt."
		comment: "Either change the transcription on the human tier or change your evaluation!"
		clicked = endPause: "Change evaluation!", "Edit the interval!", 1
	elsif intEvaluation$ == "Added"
		beginPause: "Your transcription doesn't match the prompt!"
		comment: "You've clicked Add, but the transcription doesn't match the prompt."
		comment: "You should only add an interval if the child's production matches the prompt."
		comment: "Either change the transcription on the human tier or change your evaluation!"
		clicked = endPause: "Change evaluation!", "Edit the interval!", 1
	endif	
else
	clicked = 0
	errorTranscription = 0 
#if transcriptionMatch == 0
endif

if clicked == 1 
	goto CHANGE_INT_EVAL
elsif clicked == 2
	goto EDIT
endif

endproc

###################################################	      DECIDE IF IT'S NOISY     ###################################
procedure noise
play = 0 

editor TextGrid 'textGridName$'
	Close
endeditor

if intClicked == 1 or intClicked == 4
	label AGAIN_NOISE

	if play == 0
		beginPause: "Is there any noise?"
			select sound
			plus textGrid
			View & Edit
			select textGrid
			textGridName$ = selected$ ("TextGrid", 1 )
	
			editor TextGrid 'textGridName$'
				Zoom... startHu-0.1 endHu+0.2
				Select... startHu endHu
				Play... startHu endHu
				Close
			endeditor
			play = play + 1

			comment: "Does this interval contain noise, such as..."
			comment: "	...background noise," 
			comment: "	...coughing/sneezing," 
			comment: "	...and/or speaker overlap?"
			comment: "Remember, you can only listen to the word once more before deciding!"
		noiseClicked = endPause: "Clean","Noisy", "Play again", 1

		if noiseClicked == 3
			goto AGAIN_NOISE
		endif

	else
		beginPause: "Is there any noise?"
			select sound
			plus textGrid
			View & Edit
			select textGrid
			editor TextGrid 'textGridName$'
				Zoom... startHu-0.1 endHu+0.2
				Select... startHu endHu
				Play... startHu endHu
				Close
			endeditor
			play = play + 1
		
			comment: "Does this interval contain noise, such as..."
			comment: "	...background noise," 
			comment: "	...coughing/sneezing," 
			comment: "	...or speaker overlap?"
			comment: "You have already heard the word" + string$ (play) + "x."
			comment: "You have to decide now!"
		noiseClicked = endPause: "Clean","Noisy", 1	
	endif

	if noiseClicked == 1
		noise = 0
	elif noiseClicked == 2
		noise = 1
	#if noiseClicked == X
	endif

#if intClicked == 1 or intClicked ==4
endif

endproc


###################################################	      DECIDE IF IT'S ADULT LIKE 		     ###################################
procedure adult
play = 0 

if intClicked == 1 or intClicked == 4
	label AGAIN_ADULT

	if play == 0
		beginPause: "Is there a phonemic difference?"
			select sound
			plus textGrid
			View & Edit
			select textGrid
			textGridName$ = selected$ ("TextGrid", 1 )
	
			editor TextGrid 'textGridName$'
				Zoom... startHu-0.1 endHu+0.2
				Select... startHu endHu
				Play... startHu endHu
				Close
			endeditor
			play = play + 1

			comment: "Does this word contain a phoneme-level..."
			comment: "	...addition," 
			comment: "	...deletion," 
			comment: "	...or substiution?"
			comment: "Remember, you can only listen to the word once more before deciding!"
		adultClicked = endPause: "Correct","Different", "Play again", 1

		if adultClicked == 3
			goto AGAIN_ADULT
		endif

	else
		beginPause: "Is there a phonemic difference?"
			select sound
			plus textGrid
			View & Edit
			select textGrid
			editor TextGrid 'textGridName$'
				Zoom... startHu-0.1 endHu+0.2
				Select... startHu endHu
				Play... startHu endHu
				Close
			endeditor
			play = play + 1
		
			comment: "Does this word contain a phoneme-level..."
			comment: "	...addition," 
			comment: "	...deletion," 
			comment: "	...or substiution?"
			comment: "You have already heard the word" + string$ (play) + "x."
			comment: "You have to decide now!"
		adultClicked = endPause: "Correct","Different", 1	
	endif

	if adultClicked == 1
		adult = 1
	elif adultClicked == 2
		adult = 0
	#if adultClicked == X
	endif
	
	if adult == 0
		stringOfPhonemes = Read Strings from raw text file: metadir$ + "phonemediff/" + target$ + ".txt"
		nPhon = Get number of strings
		
		#percDiff = 51
		comma = 1
		#while percDiff > 50 or comma > 0
		while comma > 0
			beginPause: "Flag all incorrect phonemes!"
				comment: "Tick all substituted and deleted phonemes"
				for iPhon to nPhon
					select stringOfPhonemes
					iPhon$ = Get string: iPhon
					boolean: "bool_" + iPhon$, 0
				endfor
				comment: "List all added phonemes separated by a semicolon (;) without a space"
				text: "Added", "NA"
			endPause: "Cont.", 1
			
			#comma-check
			comma = rindex(added$, ",")
			if comma > 0
				beginPause: "Don't use a comma"
				comment: "You used a comma to separate added phonemes."
				comment: "If more than one phoneme was added, you MUST use a semi-colon(;)"
				commaClicked = endPause: "Use semi-colon", 1	
			endif
			
			#50% check
			#sumDiff = 0
			#for iPhon to nPhon
			#	select stringOfPhonemes
			#	iPhon$ = Get string: iPhon
			#	iError$ = "bool_" + iPhon$
			#	sumDiff = sumDiff + 'iError$'
			#endfor

			
			#percDiff = (sumDiff / nPhon) * 100
			#higher than 50% error rate is acceptable when high percentage of error rate is due to "deleted phonemes" in dino, hippo, and rhino
			#if percDiff > 50 & target$ == "dinosaur"
			#	if & bool_d == 0 & bool_ae == 0 & bool_n == 0 
			#		percDiff = 49
			#	endif	
			#elif percDiff > 50 & target$ == "hippopotamus"
			#	if bool_h == 0 & bool_I == 0 & bool_p1 == 0
			#		percDiff = 49 
			#	endif
			#elif percDiff > 50 & target$ == "rhinoceros"
			#	if bool_r1 == 0 & bool_ae == 0 & bool_n == 0
			#		percDiff = 49
			#	endif
			#if target$ == "dinosaur" | target$ == "hippopotamus" | target$ == "rhinoceros"
			#endif

			#if percDiff > 50
			#	beginPause: "You flagged too many phonemes"
			#	comment: "You flagged " + string$ (percDiff) + "% of phonemes as substituted / deleted."
			#	comment: "You should reject targets when more than 50% of phonemes are incorrect."
			#	comment: "You should not flag distorted phonemes."
			#	comment: "You either need delete the interval or change the phoneme evaluations."
			#	percClicked = endPause: "Change interval eval.", "Change phoneme eval.", 1

			#	if percClicked == 1
			#		goto CHANGE_INT_EVAL
			#	endif
			#if percDiff > 50
			#endif

		#while percDiff > 50 or comma > 0
		endwhile
	#if adult == 0 
	endif

#if intClicked == 1 or intClicked ==4
endif

endproc

############################################# SAVE METADATA ##########################################################
procedure save

#add target to foundlist and add noise and difference landmarks AFTER foolproofing
if intClicked == 1 or intClicked == 4
	select stringOfFound
	Insert string: 0, target$
	
	select textGrid
	flagTime = startHu + ((endHu - startHu)/2)

	if noise == 1
		nearestFlag = Get nearest index from time: flagTier, flagTime - 0.005
		if nearestFlag != 0 
			nearestTime = Get time of point: flagTier, nearestFlag
			if nearestTime != flagTime - 0.005 
				Insert point: flagTier, flagTime - 0.005, "N"
			endif
		elsif nearestFlag == 0
			Insert point: flagTier, flagTime - 0.005, "N"
		endif
	#if noise == 1
	endif

	if adult == 0
		nError = 1
		for iPhon to nPhon
			select stringOfPhonemes
			iPhon$ = Get string: iPhon
			iError$ = "bool_" + iPhon$
			if 'iError$' == 1
				#flag location is calculated from the number/order of errors (1st error, 2nd error, etc)
				#to calculate flag location from the number/order of phonemes, multiply by nPhon instead of nError
				select textGrid
				nearestFlag = Get nearest index from time: flagTier, flagTime + (0.005*nError)
				
				if nearestFlag != 0
					nearestTime = Get time of point: flagTier, nearestFlag
					if nearestTime != flagTime + (0.005*nError)
						Insert point: flagTier, flagTime + (0.005*nError), iPhon$
					endif
				elif nearestFlag == 0
					Insert point: flagTier, flagTime + (0.005*nError), iPhon$
				endif
			
			nError = nError + 1		
			#if 'iError$' == 1	
			endif
		#for iPhon nPhon
		endfor
		
		#SAVE ADDED VALUE HERE
		if added$ != "NA"
			select textGrid
			nearestFlag = Get nearest index from time: flagTier, flagTime + (0.005*(maxError+1))
			
			if nearestFlag != 0
					nearestTime = Get time of point: flagTier, nearestFlag
					if nearestTime != flagTime + (0.005*(maxError+1))
						Insert point: flagTier, flagTime + (0.005*(maxError+1)), added$
					endif
				elif nearestFlag == 0
					Insert point: flagTier, flagTime + (0.005*(maxError+1)), added$
				endif
		#if added$ != "NA"
		endif
			
		select stringOfPhonemes
		Remove
		
	elif adult == 1
		for iError to (maxError + 1)
			nearestFlag = Get nearest index from time: flagTier, flagTime + (0.005 * iError)
			if nearestFlag != 0
				nearestTime = Get time of point: flagTier, nearestFlag
				if nearestTime == flagTime + (0.005 * iError)
					Remove point: flagTier, nearestFlag
				endif
			endif
		endfor
	#if adult == X
	endif
#if intClicked == 1 or intClicked == 4
endif

#save the metadata for the interval
if prev == 0	
	select extractionTable		
	Append row
	nRow = Get number of rows
	Set string value: nRow, "PartID", partID$
	Set string value: nRow, "Prompt", prompt$
	Set string value: nRow, "Kaldi", kaldi$
	Set string value: nRow, "Word", target$
	Set string value: nRow, "Iteration", iteration$
	Set string value: nRow, "IntervalEvaluation", intEvaluation$
	Set string value: nRow, "LabelEvaluation", labelEvaluation$
	Set string value: nRow, "BoundaryEvaluation", boundaryEvaluation$
	Set numeric value: nRow, "StartTimeIBM", 'startWindow'
	Set numeric value: nRow, "EndTimeIBM", 'endWindow'
	Set numeric value: nRow, "StartTimeHu", 'startHu'
	Set numeric value: nRow, "EndTimeHu", 'endHu'
	Set string value: nRow, "SoundFile", soundName$
	Set string value: nRow, "Annotator", annotatorName$
	Save as comma-separated file: metadir$ + "extracted_targets.csv"

	select textGrid
	editGrid = Extract one tier: huTier
	select textGrid
	flagGrid = Extract one tier: flagTier
	select promptGrid
	plus wordGrid
	plus editGrid
	plus flagGrid
	saveGrid = Merge
	Save as text file: outdir$ + saveGridName$ + ".TextGrid"
	select editGrid	
	plus flagGrid
	plus saveGrid
	Remove

	select stringOfFound
	Save as raw text file: metadir$ + itemName$+ "stringOfFound.txt"
#if prev == 0
endif

#SAVE analysis file + stringOfFound here
select analysedTable
Set numeric value: counterSoundZero , "IterationCounter", 'itValue'
Set numeric value: counterSoundZero , "IntervalCounter", 'iWord'
Set string value: counterSoundZero , "LastPrompt", prompt$
Save as comma-separated file: metadir$ + "analysed_files.csv"



#set noise and difference to 0 after saving the information
noise = 0
adult = 0

endproc

##############################################################      CHECK ANNOTATOR NAME ###############################################################
procedure whoDis
#decide who's working
annotatorName$ = ""
beginPause: "Welcome to AusKidTalk1. Enter your username!"
text: "annotatorName", " 'annotatorName$' "
endPause: "Annotate!", 1 

annotatorName$ = annotatorName$ - "  "
annotatorTable = Read Table from comma-separated file: "./metadata/annotators.csv"
iAnnotator = Search column: "Annotator", annotatorName$

if iAnnotator == 0
	pauseScript: annotatorName$, ", I don't know you, so you need to exit. If you think you typed your ID wrong, restart the script."
	goto EXIT
elif annotatorName$ == "TRAINING"
	sourcedir$ = "training/sound/"
	outdir$ = "training/corrected/"
	metadir$ = "training/metadata/"

else
	sourcedir$ = "./sound/"
	outdir$ = "./corrected/"
	metadir$ = "./metadata/"
endif	

endproc

###################################################           CREATE OR READ TRACKER FILES                   ###################################
procedure counterZero

tableexists = fileReadable(metadir$ + "analysed_files.csv")

if nFile == 0
	notFound$ = "No data found. Go the webtool and download your zip file."
	call fileNotFound
	
elsif tableexists == 0 and nFile == 1
	analysedTable = Create Table with column names: "analysedTable", nFile, "SoundFile SpeakerTier SoundCounter IterationCounter IntervalCounter LastPrompt Annotator"

	select Strings participantList
	partID$ = Get string: nFile
	select analysedTable 
	Set string value: nFile, "SoundFile", partID$ + "_task1.wav"

	Formula: "SoundCounter", "0"
	Formula: "IterationCounter", "0"
	Formula: "IntervalCounter", "0"
	Formula: "Annotator", "annotatorName$"
	Save as comma-separated file: metadir$ + "analysed_files.csv"

elsif tableexists == 0 and nFile > 1
	beginPause: "Missing file"
	comment: "Error: analysed_files.csv is missing from the metadata folder."
	comment: "EXIT the script and contact your supervisor!"
	endPause: "Exit", 1
	goto EXIT
elsif tableexists == 1
	analysedTable = Read Table from comma-separated file: metadir$ + "analysed_files.csv"
endif

#find the unfinished file by annotatorName$ or add new file
nRow = Get number of rows
assignedAnnotator = Search column: "Annotator", annotatorName$

if assignedAnnotator > 0
	currentAnnotatorTable = Extract rows where column (text): "Annotator", "is equal to", annotatorName$
	unfinishedFile = Search column: "SoundCounter", "0"
else
	unfinishedFile = 0
endif

if assignedAnnotator > 0 and unfinishedFile > 0
	select currentAnnotatorTable
 	fileInProgress$ = Get value: unfinishedFile, "SoundFile"
	partID$ = fileInProgress$ - "_task1.wav"
	select analysedTable
	counterSoundZero = Search column: "SoundFile", fileInProgress$
else 
	#find new file
	Create Strings from tokens: "analysedfiles", "",  " ,"
	for iRow to nRow
		select analysedTable
		currentFile$ = Get value: iRow, "SoundFile"
		currentPart$ = currentFile$ - "_task1.wav"
	
		select Strings analysedfiles
		Insert string: 0, currentPart$
	
	endfor	

	select Strings analysedfiles
	analysedList = To WordList


	isChecked = 1
	iFile = 1
	repeat
		select Strings participantList
		partID$ = Get string: iFile

		select analysedList
		isChecked = Has word: partID$
	
		iFile = iFile + 1
	until isChecked == 0 or iFile > nFile
	


	if isChecked == 0
	#add new file	to table
	select analysedTable 
	Append row
	counterSoundZero = Get number of rows
	Set string value: counterSoundZero, "SoundFile", partID$ + "_task1.wav"
	Set numeric value: counterSoundZero, "SoundCounter", 0
	Set numeric value: counterSoundZero, "IterationCounter", 0
	Set numeric value: counterSoundZero, "IntervalCounter", 0
	Set string value: counterSoundZero, "Annotator", annotatorName$
	Save as comma-separated file: metadir$ + "analysed_files.csv"
	

	#add warning to download
	elif isChecked == 1 
		beginPause: "You've analysed all the files!"
			comment: "All the files you have downloaded have been hand-checked."
			comment: "Download new files from the webtool!"
			comment: "Or take a break :)"
		endPause: "Exit", 1
		goto EXIT
	endif

endif

if assignedAnnotator == 1
	select currentAnnotatorTable
	Remove
endif

select analysedTable
fileName$ = Get value: counterSoundZero, "SoundFile"
itValue = Get value: counterSoundZero, "IterationCounter"
ogItValue = Get value: counterSoundZero, "IterationCounter"
intValue = Get value: counterSoundZero, "IntervalCounter"
lastPrompt$ = Get value: counterSoundZero, "LastPrompt"

if itValue > 0 
	reload = 1
	if itValue == 1
		beginPause: "Continue working"
		comment: "File: " + fileName$ 
		comment: "Iteration: " + string$ (itValue)
		comment: "The ASR matched the child's speech with the prompt"
		endPause: "Continue", 1
	elsif itValue == 2
		beginPause: "Continue working"
		comment: "File: " + fileName$ 
		comment: "Iteration: " + string$ (itValue)
		comment: "The ASR identified the child's voice, but not the target"
		endPause: "Continue", 1
	elsif itValue == 3
		beginPause: "Continue working"
		comment: "File: " + fileName$ 
		comment: "Iteration: " + string$ (itValue)
		comment: "The ASR couldn't identify the child's voice"
		endPause: "Continue", 1
	endif		

else 
	reload = 0
endif

tableexists = fileReadable(metadir$ + "extracted_targets.csv")

if tableexists == 0
	extractionTable = Create Table with column names: "extractionTable", 0, "PartID Prompt Kaldi Word Iteration IntervalEvaluation LabelEvaluation BoundaryEvaluation StartTimeIBM EndTimeIBM StartTimeHu EndTimeHu SoundFile Annotator"
elsif tableexists == 1
	extractionTable = Read Table from comma-separated file: metadir$ +  "extracted_targets.csv"
endif

endproc

################################################## GRACEFUL EXIT AND ERROR MESSAGE IF A FILE IS NOT FOUND ###########################################
procedure fileNotFound

beginPause: "Missing file"
comment: notFound$
comment: "Contact your supervisor if you think you lost work."
endPause: "Exit", 1
goto EXIT

endproc
