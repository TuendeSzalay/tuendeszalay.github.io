# OVERVIEW
# This script was written for the AusKidTalk project (LE190100187, website: https://www2.ee.unsw.edu.au/~auskidtalk/index.html) by Tuende Szalay (tuende.szalay@sydney.edu.au). 

# The aim of this script is to assist annotators in providing time-aligned orthorgaphic transcription for Task(1) files for which automatic transcription was not generated.

# Annotator tasks:
## Listen to the audio.
## Add the target words in the order in which they are expected to occur.
## Decide if a target word contains noise or mispronunciation.

# Input:
## Input data are created during manual task identification (see script: 1find_Tasks.praat).
## Input data are in the task1 folder
## One participant's data consists of one file:
### Task(1) wav file, named as ChildID_task1.wav (e.g., 98_task1.wav)

# Output:
# Output data are saved by the script in the task1 folder.
# There are two additional files created for each corrected participant:
## Task(1) textgrid with the manual orthographic transcription named as ChildID_task1_corrected.TextGrid (e.g., 98_task1_corrected.TextGrid)
## Task(1) csv containing the manually identified targets and their start- and end-times in a csv file named as ChildID_task1_corrected.csv (e.g., 98_task1_corrected.TextGrid )

# Metadata:
# The metadata folder contains a set of txt and csv files required for the script.
# Target lists
## prompts.txt lists all the prompts used in AusKidTalk Task(1)
# Phonetic transcriptions
## Phonetic transcriptions are provided for every target in the folder phonemediff.
## Transcriptions follow a non-traditional system used solely for the AusKidTalk project to avoid the need to code IPA symbols
# Tracker file for annotators' decision
## The file extracted_targets.csv logs annotators decision on the interval, the orhographic transcription, and the boundary.

# FURTHER DETAILS
# For details of automatic transcription, see
# Szalay, T., Shahin, M., Sirojan, T., Nan, Z., Huang, R., Ballard, K., Ahmed, B. (2025) AusKidTalk: Using Strategic Data Collection and Out-of-Domain Tools to Semi-Automate Novel Corpora Annotation. Proceedings of the 26th INTERSPEECH Conference, 4268-4272.
# For details of hand-correction of automatic transcription, see
# Szalay, T., Ratko, L., Shahin, M., Sirojan, T., Ballard, K., Cox, F., & Ahmed, B. (2022). A semi-automatic workflow for orthographic transcription of a novel speech corpus: A case study of AusKidTalk. In Rosey Billington (Ed.) Proceedings of the 18th Australasian International Conference on Speech Science and Technology, 126-130.
# For more details on AusTalk, see
# Ahmed, B., Ballard, K. J., Burnham, D., Sirojan, T., Mehmood, H., Estival, D., ... & Ambikairajah, E. (2021). AusKidTalk: an auditory-visual corpus of 3-to 12-year-old Australian children’s speech. In Proc. Interspeech 2021 (pp. 3680-3684).

# REFERENCE
# If you use this script, please cite any of the papers above, as relevant.

# ACKNOWLEDGMENT
# This work was supported by the Australian Research Council LE190100187 Grant.
# Special thanks for Titia Benders for her help in writing the counterParticipant procedure

#Define directories
sourcedir$ = "./sound/"
nTask = 5

for iTask to nTask
	createFolder: "task" + string$ (iTask)
endfor	

#Create countertable for PARTICIPANTS (i.e., sound files)
call counterParticipant

for iParticipant from counterParticipantZero to nParticipant
	stopwatch
	#load sound file & get duration
	select speakerTable
	soundName$ = Get value: iParticipant, "SoundFile"
	gridName$ = soundName$ - ".wav"
	gridName$ = gridName$ + ".TextGrid"

	#get participant name
	break = index(soundName$, " ")
	partID$ = left$(soundName$, break-1)

	
	sound = Read from file: sourcedir$ + soundName$
	dur = Get total duration
	
	#read or generate textgrid	
	gridExists = fileReadable(sourcedir$ + gridName$)
	
	if gridExists == 1
		textGrid = Read from file: sourcedir$ + gridName$
	else	
		textGrid = To TextGrid: "Task", ""

		#writeInfoLine("task", tab$, "start", tab$, "end", tab$, "dur")
		for iTask to nTask
			#Note: dur/nTask * iTask can give a number > than total sound/grid dur due to rounding errors, so a neg constant was added
			if iTask < 3
				taskDurLong = dur * 0.299
				startTask = 30 + (taskDurLong * (iTask - 1))
				endTask = 10 + (taskDurLong * iTask)
				#appendInfoLine(iTask, tab$, startTask, tab$, endTask, tab$, taskDurLong)
			elif iTask >=3
				taskDurShort = dur * 0.299 / 3
				startTask = (10 + 2*taskDurLong) + 30 + (taskDurShort * (iTask - 3))
				endTask = (10 + 2*taskDurLong) + 10 +(taskDurShort * (iTask - 2))
				#appendInfoLine(iTask, tab$, startTask, tab$, endTask, tab$, taskDurShort)
			endif
			
			
			
			Insert boundary: 1, startTask
			if endTask < dur
				Insert boundary: 1, endTask
			else
				Insert boundary: 1, dur - 10
			endif
			intTask = Get low interval at time: 1, endTask
			Set interval text: 1, intTask, "task" + string$ (iTask)
		endfor
	endif	
	
	#get previously saved info from speakerTable
	select speakerTable
	commentString$ =  Get value: iParticipant, "Comment"
	counterValue = Get value: iParticipant, "Counter"
	
	#open to edit
	textGridName$ = gridName$ - ".TextGrid"
	select sound
	plus textGrid
	View & Edit
	
	counterValue$ = string$ (counterValue) 
	beginPause: "Annotate!"
	comment: "You have seen this sound file " + "'counterValue$'" + " times"
	comment: "Mark boundaries for all completed tasks"
	comment: "Remove boundaries for missing tasks"
	#comment: "Tick off completed tasks"
	
	#boolean: "task1Complete", 'task1Complete'
	#boolean: "task2Complete", 'task2Complete'
	#boolean: "task3Complete", 'task3Complete'
	#boolean: "task4Complete", 'task4Complete'
	#boolean: "task5Complete", 'task5Complete'
	text: "commentString", "'commentString$'"
	
	clicked = endPause:  "Prev. file", "Save & next", 2
	if clicked = 1
		iParticipant = iParticipant - 2
		if iParticipant < 0
			iParticipant = 0
			pauseScript: "You are analysing the first file. Move to the next!"
		endif
	endif
	
	#save - NO PAUSING MID FILE
	select textGrid
	Save as text file: sourcedir$ + gridName$
	
	# extract found tasks 
	select textGrid
	gridTable = Down to Table: "no", 6, "yes", "no"	
	nTaskComplete = Get number of rows
	
	for iTaskComplete to nTaskComplete
		select gridTable
		iTaskStart = Get value: iTaskComplete, "tmin"
		iTaskEnd = Get value: iTaskComplete, "tmax"
		iTaskLabel$ = Get value: iTaskComplete, "text"
		
		select sound
		iTaskSound = Extract part: iTaskStart, iTaskEnd, "rectangular", 1, "no"
		Save as WAV file: iTaskLabel$ + "/" + partID$ + "_" + iTaskLabel$ + ".wav"
		Remove
		
		select speakerTable
		iTaskNumber$ = right$ (iTaskLabel$, 1)
		colName$ = "Task" + iTaskNumber$ + "Complete"
		iTaskDur = iTaskEnd - iTaskStart
		Set numeric value: iParticipant, colName$, iTaskDur
		
	endfor
		
	#clean up
	select sound
	plus textGrid
	plus gridTable
	Remove
	
	#save metadata
	select speakerTable
	Set string value: iParticipant, "ParticipantID", partID$
	Set numeric value: iParticipant, "Counter", counterValue+1
	#Set numeric value: iParticipant, "Task1Complete", task1Complete
	#Set numeric value: iParticipant, "Task2Complete", task2Complete
	#Set numeric value: iParticipant, "Task3Complete", task3Complete
	#Set numeric value: iParticipant, "Task4Complete", task4Complete
	#Set numeric value: iParticipant, "Task5Complete", task5Complete
	#Set string value: iParticipant, "Comment", commentString$
	time = stopwatch
	Set numeric value: iParticipant, "AnnotationTime_s", time
	Save as comma-separated file: sourcedir$ + "annotated_participants_all_tasks.csv"	

#for iParticipant from counterParticipantZero to nParticipant
endfor

pauseScript: "You annotated all long files!"

############ PROCEDURE counterParticipant ####################
# Finds files with no annotation and allows top-ups

#Generate tracker file containing a column for task completed for each tasks + comment
procedure counterParticipant

Create Strings as file list:  "currentList", sourcedir$ + "*.wav"
nCurrent = Get number of strings
nSound = Get number of strings

tableexists = fileReadable(sourcedir$ + "annotated_participants_all_tasks.csv")

if tableexists = 1
	speakerTable = Read Table from comma-separated file: sourcedir$ + "annotated_participants_all_tasks.csv"
else
	#dump all files into a new table
	speakerTable = Create Table with column names: "speakerTable", nCurrent, "ParticipantID Counter Task1Complete Task2Complete Task3Complete Task4Complete Task5Complete Comment SoundFile AnnotationTime_s" 
	for iCurrent to nCurrent
		select Strings currentList
		currentSound$ = Get string: iCurrent
		#currentPart$ = currentSound$ - "_sentences.wav"
		select speakerTable
		#Set string value: iCurrent, "ParticipantID", currentPart$
		Set string value: iCurrent, "SoundFile", currentSound$
		Set numeric value: iCurrent, "Counter", 0

	endfor	
endif

select speakerTable
counterParticipantZero  = Search column: "Counter", "0" 

#if there are no new files in the TABLE, check the FOLDER
if counterParticipantZero == 0
	for iCurrent to nCurrent
		select Strings currentList
		select Strings currentList
		currentPart$ = Get string: iCurrent
		
		select speakerTable
		partExists = Search column: "SoundFile", currentPart$
		if partExists == 0
			Append row
			newRow = Get number of rows
			Set string value: newRow, "ParticipantID", currentPart$ - "_sentences.wav"
			Set string value: newRow, "SoundFile", currentPart$
			Set numeric value: newRow, "Counter", 0
		endif	
	endfor
#if counterParticipantZero == 0
endif

#check if we found new files
select speakerTable
nParticipant = Get number of rows
counterParticipantZero = Search column: "Counter", "0" 

if counterParticipantZero == 0
	countZero$ = "You've checked all files."	
else
	countZero$ = "Start working with file "  + string$ ( counterParticipantZero )
endif	

beginPause: "Select your file!"
		comment: countZero$
		comment: "Do you want to change to another file?"
		positive: "counterParticipantZero", counterParticipantZero 
	endPause: "Happy annotating!" , 1

	if counterParticipantZero > nSound
		pauseScript: "There are only  ", nSound, " files ",  ". Select a number below ", nSound
endif

endproc
