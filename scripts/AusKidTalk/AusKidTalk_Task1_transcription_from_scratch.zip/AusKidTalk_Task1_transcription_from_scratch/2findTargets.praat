# OVERVIEW
# This script was written for the AusKidTalk project (LE190100187, website: https://www2.ee.unsw.edu.au/~auskidtalk/index.html) by Tuende Szalay (tuende.szalay@sydney.edu.au). 

# The aim of this script is to assist annotators in providing time-aligned orthorgaphic transcription for Task(1) files for which automatic transcription was not generated.

# Annotator tasks:
## Listen to the audio.
## Identify start and end times for each task and mark it on a textgrid

# Input:
## Input data are placed in the sound folder
## One participant's data consists of one file:
### Audio file, named as ChildID_ Primary_XX-XX.wav (e.g., 750 Primary_49-01.wav)

# Output:
# Output data are saved by the script in the sound folder.
# There is one additional file created for each corrected participant:
## A textgrid with the manually identified task boundaries named as ChildID_ Primary_XX-XX.TextGrid (e.g., 750 Primary_49-01.TextGrid)

# FURTHER DETAILS
# For details of automatic transcription, see
# Szalay, T., Shahin, M., Sirojan, T., Nan, Z., Huang, R., Ballard, K., Ahmed, B. (2025) AusKidTalk: Using Strategic Data Collection and Out-of-Domain Tools to Semi-Automate Novel Corpora Annotation. Proceedings of the 26th INTERSPEECH Conference, 4268-4272.
# For details of hand-correction of automatic transcription, see
# Szalay, T., Ratko, L., Shahin, M., Sirojan, T., Ballard, K., Cox, F., & Ahmed, B. (2022). A semi-automatic workflow for orthographic transcription of a novel speech corpus: A case study of AusKidTalk. In Rosey Billington (Ed.) Proceedings of the 18th Australasian International Conference on Speech Science and Technology, 126-130.
# For more details on AusTalk, see
# Ahmed, B., Ballard, K. J., Burnham, D., Sirojan, T., Mehmood, H., Estival, D., ... & Ambikairajah, E. (2021). AusKidTalk: an auditory-visual corpus of 3-to 12-year-old Australian children’s speech. In Proc. Interspeech 2021 (pp. 3680-3684).

# REFERENCE
# If you use this script, please cite any of the papers above, as relevant.

# ACKNOWLEDGMENT
# This work was supported by the Australian Research Council LE190100187 Grant.
# Special thanks for Titia Benders for her help in writing the counterParticipant procedure


#Define directories
sourcedir$ = "./task1/"
metadir$ = "./metadata/"

huTier = 1
flagTier = 2
maxError = 11

#load prompt list
# LOAD PROMPT.TXT WHEN NOT TRAINING!!!!
promptList = Read Strings from raw text file: metadir$ + "prompt.txt"
nTarget = Get number of strings

call counterParticipant

for iParticipant from counterParticipantZero to nParticipant
	stopwatch
	
	#get info
	select speakerTable
	soundName$ = Get value: iParticipant, "SoundFile"
	saveGridName$ = soundName$ - ".wav"
	saveGridName$ = saveGridName$ + "_corrected.TextGrid"
	
	counterValue = Get value: iParticipant, "Counter"

	break = index(soundName$, " ")
	partID$ = left$(soundName$, break-1)
	
	#load sound file and load/generate grid
	sound = Read from file: sourcedir$ + soundName$
	
	gridExists = fileReadable(sourcedir$ + saveGridName$)
	if gridExists == 1
		textGrid = Read from file: sourcedir$ + saveGridName$
	else	
		textGrid = To TextGrid: "hu-wrd, flag", "flag"
	endif
	
	#goto TEST
	#find all targets
	select sound
	plus textGrid
	View & Edit
	
	for iTarget to nTarget
		select promptList
		iTarget$ = Get string: iTarget
		
		if iTarget$ == "COUNT_EGGS_IN_GRASS"
			instruction1$ = "Mark numbers FROM ONE TO TEN for count_eggs_in_grass"
			instruction2$ = "Don't mark numbers that you can't find"
		else
			instruction1$ = "Mark boundaries for all instances of " + iTarget$
			instruction2$ = "If the child did not say " + iTarget$ + ", click Save & Next"
			
		endif

		beginPause: "Annotate!"
		comment: instruction1$
		comment: instruction2$
		comment: "Follow AusKidTalk rules"
		clicked = endPause:  "Prev. target", "Save & next", 2
		
		if clicked = 1
			iTarget = iTarget - 2
			if iTarget < 0
				iTarget = 0
				pauseScript: "You are analysing the first target. Move to the next!"
			endif
		endif
		
		#Save but no logging/pause
		select textGrid
		Save as text file: sourcedir$ + saveGridName$
	endfor
	
	pauseScript: "You've added all the targets. Now you'll add flags. THE EDITOR WILL CLOSE"
	
	select textGrid
	textGridName$ = selected$ ("TextGrid", 1 )
	editor TextGrid 'textGridName$'
			Close
	endeditor
	
	select textGrid
	targGrid = Extract one tier: 1
	gridTable = Down to Table: "no", 6, "yes", "no"	
	nTargetComplete = Get number of rows
	
	for iTargetComplete to nTargetComplete
		select gridTable
		startHu = Get value: iTargetComplete, "tmin"
		endHu = Get value: iTargetComplete, "tmax"
		target$ = Get value: iTargetComplete, "text"
		
		flagTime = startHu + ((endHu - startHu)/2)
		
		call noise
		call adult
		select textGrid
		Save as text file: sourcedir$ + saveGridName$
		
	#for iTargetComplete to nTargetComplete
	endfor
	
	#label TEST
	# generate table and save final CSV
	select textGrid
	editGrid = Extract one tier: huTier
	select textGrid
	flagGrid = Extract one tier: flagTier

	select editGrid
	allHuTable = Down to Table: "no", 6, "yes", "no"
	targHuTable = Extract rows where column (text): "text", "is not equal to", "sil"
	Append column: "Noise"
	Append column: "Difference1"
	Append column: "Difference2"
	Append column: "Difference3"
	Append column: "Difference4"
	Append column: "Difference5"
	Append column: "Difference6"
	Append column: "Difference7"
	Append column: "Difference8"
	Append column: "Difference9"
	Append column: "Difference10"
	Append column: "Difference11"
	Append column: "Added"
	Formula: "Difference1", """NA"""
	Formula: "Difference2", """NA"""
	Formula: "Difference3", """NA"""
	Formula: "Difference4", """NA"""
	Formula: "Difference5", """NA"""
	Formula: "Difference6", """NA"""
	Formula: "Difference7", """NA"""
	Formula: "Difference8", """NA"""
	Formula: "Difference9", """NA"""
	Formula: "Difference10", """NA"""
	Formula: "Difference11", """NA"""
	Formula: "Added", """NA"""
	Formula: "Noise", """FALSE"""
	nHuInt = Get number of rows
	for iHuInt to nHuInt
		select targHuTable
		cTMin = Get value: iHuInt, "tmin"
		#cTMin$ = fixed$ (cTMin, 2)
		#cTMin = number (cTMin$)
		cTMax = Get value: iHuInt, "tmax"
		#cTMax$ = fixed$ (cTMax, 2)
		#cTMax = number (cTMax$)
		cTMid = cTMin + ((cTMax - cTMin)/2) 

		select textGrid
		lowIndex = Get low index from time: flagTier, cTMid
		maxIndex = Get number of points: flagTier
	
		if lowIndex != 0
			select textGrid
			lowTime = Get time of point: flagTier, lowIndex
			if lowTime > cTMin 
				select targHuTable
				Set string value: iHuInt, "Noise", "TRUE"
			endif	
		endif
	
		for iError to maxError
			expectedTime =  cTMid + 0.005 * iError
			expectedTime = 'expectedTime:3'

			select textGrid
			highIndex = Get nearest index from time: flagTier, expectedTime


			if highIndex != 0 and highIndex <= maxIndex
				select textGrid
				highTime = Get time of point: flagTier, highIndex 
				highTime = 'highTime:3'

				#writeInfoLine(iHuInt, tab$, cTMid, tab$, expectedTime, tab$, highIndex, tab$, highTime)
				#pauseScript: "TEST"

				if highTime == expectedTime and highTime < cTMax
					select textGrid
					phon$ = Get label of point: flagTier, highIndex 
					select targHuTable
					if iError <= maxError	
						Set string value: iHuInt, "Difference" + string$(iError), phon$
					elif iError == maxError + 1
						Set string value: iHuInt, "Added", phon$
					endif
				endif
			endif
		#for maxError errors
		endfor
	
	#for iHuInt to nHuInt
	endfor
	
	select targHuTable
	csvName$ = saveGridName$ - ".TextGrid"
	Save as comma-separated file: sourcedir$ + csvName$ + ".csv"
	
	#clean up
	select sound
	plus textGrid
	plus targGrid
	plus gridTable
	plus editGrid
	plus flagGrid
	plus allHuTable
	plus targHuTable
	Remove

	#save annotation table
	select speakerTable
	Set string value: iParticipant, "ParticipantID", partID$
	Set numeric value: iParticipant, "Counter", counterValue+1
	time = stopwatch
	Set numeric value: iParticipant, "AnnotationTime_s", time
	Save as comma-separated file: sourcedir$ + "annotated_participants_task1.csv"	
	

#for iParticipant from counterParticipantZero to nParticipant
endfor

pauseScript: "Hurray, you're done!"

############ PROCEDURE flagNoise ######################
# copied from AKT1
# modified by in-built adding of flags rather than adding flags as part of an additional "save" procedure

procedure noise
play = 0 

label AGAIN_NOISE

if play == 0
	beginPause: "Is there any noise?"
		select sound
		plus textGrid
		View & Edit
		select textGrid
		textGridName$ = selected$ ("TextGrid", 1 )

		editor TextGrid 'textGridName$'
			Zoom... startHu-0.1 endHu+0.2
			Select... startHu endHu
			Play... startHu endHu
			Close
		endeditor
		play = play + 1

		comment: "Does this interval contain noise, such as..."
		comment: "	...background noise," 
		comment: "	...coughing/sneezing," 
		comment: "	...and/or speaker overlap?"
		comment: "Remember, you can only listen to the word once more before deciding!"
	noiseClicked = endPause: "Clean","Noisy", "Play again", 1

	if noiseClicked == 3
		goto AGAIN_NOISE
	endif

else
	beginPause: "Is there any noise?"
		select sound
		plus textGrid
		View & Edit
		select textGrid
		editor TextGrid 'textGridName$'
			Zoom... startHu-0.1 endHu+0.2
			Select... startHu endHu
			Play... startHu endHu
			Close
		endeditor
		play = play + 1
	
		comment: "Does this interval contain noise, such as..."
		comment: "	...background noise," 
		comment: "	...coughing/sneezing," 
		comment: "	...or speaker overlap?"
		comment: "You have already heard the word" + string$ (play) + "x."
		comment: "You have to decide now!"
	noiseClicked = endPause: "Clean","Noisy", 1	
endif

if noiseClicked == 1
	noise = 0
elif noiseClicked == 2
	#add noise flag
	noise = 1
	
	nearestFlag = Get nearest index from time: flagTier, flagTime - 0.005
		if nearestFlag != 0 
			nearestTime = Get time of point: flagTier, nearestFlag
			if nearestTime != flagTime - 0.005 
				Insert point: flagTier, flagTime - 0.005, "N"
			endif
		elsif nearestFlag == 0
			Insert point: flagTier, flagTime - 0.005, "N"
		endif
		
#if noiseClicked == X
endif


endproc

############ PROCEDURE adultLike ####################
# copied from AKT1
# cleaned up from AKT1 by removing the requirement for at least 50% of the phonemes to be correct
# modified by in-built adding of flags rather than adding flags as part of an additional "save" procedure

procedure adult
play = 0 

label AGAIN_ADULT

if play == 0
	beginPause: "Is there a phonemic difference?"
		select sound
		plus textGrid
		View & Edit
		select textGrid
		textGridName$ = selected$ ("TextGrid", 1 )

		editor TextGrid 'textGridName$'
			Zoom... startHu-0.1 endHu+0.2
			Select... startHu endHu
			Play... startHu endHu
			Close
		endeditor
		play = play + 1

		comment: "Does this word contain a phoneme-level..."
		comment: "	...addition," 
		comment: "	...deletion," 
		comment: "	...or substiution?"
		comment: "Remember, you can only listen to the word once more before deciding!"
	adultClicked = endPause: "Correct","Different", "Play again", 1

	if adultClicked == 3
		goto AGAIN_ADULT
	endif

else
	beginPause: "Is there a phonemic difference?"
		select sound
		plus textGrid
		View & Edit
		select textGrid
		editor TextGrid 'textGridName$'
			Zoom... startHu-0.1 endHu+0.2
			Select... startHu endHu
			Play... startHu endHu
			Close
		endeditor
		play = play + 1
	
		comment: "Does this word contain a phoneme-level..."
		comment: "	...addition," 
		comment: "	...deletion," 
		comment: "	...or substiution?"
		comment: "You have already heard the word" + string$ (play) + "x."
		comment: "You have to decide now!"
	adultClicked = endPause: "Correct","Different", 1	
endif

if adultClicked == 1
	adult = 1
elif adultClicked == 2
	adult = 0
#if adultClicked == X
endif

#Flag incorrect phonemes
if adult == 0
	stringOfPhonemes = Read Strings from raw text file: metadir$ + "phonemediff/" + target$ + ".txt"
	nPhon = Get number of strings
	
	comma = 1
	while comma > 0
		beginPause: "Flag all incorrect phonemes!"
			comment: "Tick all substituted and deleted phonemes"
			for iPhon to nPhon
				select stringOfPhonemes
				iPhon$ = Get string: iPhon
				boolean: "bool_" + iPhon$, 0
			endfor
			comment: "List all added phonemes separated by a semicolon (;) without a space"
			text: "Added", "NA"
		endPause: "Cont.", 1
		
		#comma-check
		comma = rindex(added$, ",")
		if comma > 0
			beginPause: "Don't use a comma"
			comment: "You used a comma to separate added phonemes."
			comment: "If more than one phoneme was added, you MUST use a semi-colon(;)"
			commaClicked = endPause: "Use semi-colon", 1	
		endif
		
	#while comma > 0
	endwhile
	
#if adult == 0 
endif

# Add incorrect phonemes to flag tier
if adult == 0
		nError = 1
		for iPhon to nPhon
			select stringOfPhonemes
			iPhon$ = Get string: iPhon
			iError$ = "bool_" + iPhon$
			if 'iError$' == 1
				#flag location is calculated from the number/order of errors (1st error, 2nd error, etc)
				#to calculate flag location from the number/order of phonemes, multiply by nPhon instead of nError
				select textGrid
				nearestFlag = Get nearest index from time: flagTier, flagTime + (0.005*nError)
				
				if nearestFlag != 0
					nearestTime = Get time of point: flagTier, nearestFlag
					if nearestTime != flagTime + (0.005*nError)
						Insert point: flagTier, flagTime + (0.005*nError), iPhon$
					endif
				elif nearestFlag == 0
					Insert point: flagTier, flagTime + (0.005*nError), iPhon$
				endif
			
			nError = nError + 1		
			#if 'iError$' == 1	
			endif
		#for iPhon nPhon
		endfor
		
		#SAVE ADDED VALUE HERE
		if added$ != "NA"
			select textGrid
			nearestFlag = Get nearest index from time: flagTier, flagTime + (0.005*(maxError+1))
			
			if nearestFlag != 0
					nearestTime = Get time of point: flagTier, nearestFlag
					if nearestTime != flagTime + (0.005*(maxError+1))
						Insert point: flagTier, flagTime + (0.005*(maxError+1)), added$
					endif
				elif nearestFlag == 0
					Insert point: flagTier, flagTime + (0.005*(maxError+1)), added$
				endif
		#if added$ != "NA"
		endif
			
		select stringOfPhonemes
		Remove
		
	elif adult == 1
		for iError to (maxError + 1)
			nearestFlag = Get nearest index from time: flagTier, flagTime + (0.005 * iError)
			if nearestFlag != 0
				nearestTime = Get time of point: flagTier, nearestFlag
				if nearestTime == flagTime + (0.005 * iError)
					Remove point: flagTier, nearestFlag
				endif
			endif
		endfor
	#if adult == X
	endif

endproc

############ PROCEDURE counterParticipant ####################
# Finds files with no annotation and allows top-ups
# Generate tracker file containing a column for task completed for each tasks + comment
procedure counterParticipant

Create Strings as file list:  "currentList", sourcedir$ + "*.wav"
nCurrent = Get number of strings
nSound = Get number of strings

tableexists = fileReadable(sourcedir$ + "annotated_participants_task1.csv")

if tableexists = 1
	speakerTable = Read Table from comma-separated file: sourcedir$ + "annotated_participants_task1.csv"
else
	#dump all files into a new table
	speakerTable = Create Table with column names: "speakerTable", nCurrent, "ParticipantID Counter SoundFile AnnotationTime_s" 
	for iCurrent to nCurrent
		select Strings currentList
		currentSound$ = Get string: iCurrent
		#currentPart$ = currentSound$ - "_sentences.wav"
		select speakerTable
		#Set string value: iCurrent, "ParticipantID", currentPart$
		Set string value: iCurrent, "SoundFile", currentSound$
		Set numeric value: iCurrent, "Counter", 0

	endfor	
endif

select speakerTable
counterParticipantZero = Search column: "Counter", "0" 

#if there are no new files in the TABLE, check the FOLDER
if counterParticipantZero == 0
	for iCurrent to nCurrent
		select Strings currentList
		select Strings currentList
		currentPart$ = Get string: iCurrent
		
		select speakerTable
		partExists = Search column: "SoundFile", currentPart$
		if partExists == 0
			Append row
			newRow = Get number of rows
			Set string value: newRow, "ParticipantID", currentPart$ - "_sentences.wav"
			Set string value: newRow, "SoundFile", currentPart$
			Set numeric value: newRow, "Counter", 0
		endif	
	endfor
#if counterParticipantZero == 0
endif

#check if we found new files
select speakerTable
nParticipant = Get number of rows
counterParticipantZero = Search column: "Counter", "0" 

if counterParticipantZero == 0
	countZero$ = "You've checked all files."	
else
	countZero$ = "Start working with file "  + string$ (counterParticipantZero)
endif	

beginPause: "Select your file!"
		comment: countZero$
		comment: "Do you want to change to another file?"
		positive: "counterParticipantZero", counterParticipantZero
	endPause: "Happy annotating!" , 1

	if counterParticipantZero > nSound
		pauseScript: "There are only  ", nSound, " files ",  ". Select a number below ", nSound
endif

endproc
