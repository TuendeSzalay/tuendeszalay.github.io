README

Three scripts are provided for the following paper:
Noyan-Erbaş, A., Zeynep Kurada, H., Szalay, T., Karamete, A., Thomas, D., and McCabe, P. (in prep). An analysis of lexical stress production of Turkish speaking children.

SAMPLE DATA
Sample audio data are not provided to protect participants' privacy.
Data are to be placed in the folder long_sound, with each participant's data placed in their own subfolder (e.g., long_sound/TDF2 for a typically-developing female child with the participant ID 2).
The wav file is expected to contain all repetitions of all target words.
The accompanying textgrid was generated in Phon, with expected and actual productions with broad transcription.

SCRIPTS
Script 1: 1_extractWord.Praat
This script extracts the pre-defined target words listed in the text files swList.txt and wsList.txt as separate wav files and saves them in the folder extracted_sounds.

Script 2: 2_correctBoundary.Praat
This script provides a Praat interface for hand-correcting vowel boundaries in the individual target words.

Script 3: 3_correlatesOfStress.Praat
This script extracts F0, intensity, and duration measures form the vowels based on the manually corrected segmentation and saves it together with speaker, word, repetition, and stress (strong-weak or weak-strong) information in a comma-separated file named as extracted_stress_measures.csv
If the output appears to contain distorted text with question marks or boxes when opening in Excel, the encoding is incorrect.
The file can be opened in Notepad++ with UTF-16 BE BOM encoding or imported into a new Excel with 1201: Unicode (Big Endian) using the "Import data from file" function.

REFERENCES
For scripts 1 and 3, please cite Noyan-Erbaş, A., Zeynep Kurada, H., Szalay, T., Karamete, A., Thomas, D., and McCabe, P. (in prep). An analysis of lexical stress production of Turkish speaking children.
For script 2 please cite both Noyan-Erbaş et al. (in prep) as above, as well as  Szalay, T., Benders, T., Cox, F. & Proctor, M. (2022). Vowel merger in Australian English lateral-final rimes: /æɔ-æ/. In Rosey Billington (Ed.) Proceedings of the 18th Australasian International Conference on Speech Science and Technology, (pp. 106-110). 

CONTACT
Ayşın Noyan Erbas: aysinnoyanerbas@gmail.com
Tuende Szalay: tuende0szalay@gmail.com